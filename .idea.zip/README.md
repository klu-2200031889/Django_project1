# Online-Blood-Donation-Management-System-in-Python-Django
Blood Donation is essential for people in urgent need of it, which can save millions of patients. Hence blood donation management system is very much important. Here we will develop a Blood Donation management system using Python in easy steps.
## About the Blood Donation Management System:
The patients in need of the blood can request the blood. Users can register themselves to become a donor. All users can also see all the donor lists according to different blood groups and the list of all the requested blood by different users or patients. The patients who need the blood can contact the available donors of the same blood group and city. This will help many people who need blood.
